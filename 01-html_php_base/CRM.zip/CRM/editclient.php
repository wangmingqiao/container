<?php include 'common/header.html' ?>

<?php
    $host = 'localhost';
    $user = 'root';
    $pwd = '123456';
    $db = 'crm';
    $pdo = new PDO("mysql:host=$host;dbname=$db",$user,$pwd);

    $c_name = $_GET['c_name'];
    // $inlineRadioOptions = $_POST['inlineRadioOptions'];

    // echo $inlineRadioOptions;

    $sql= $pdo->query("SELECT * FROM client WHERE c_name='$c_name'");

    foreach ($sql as $row) {
        // var_dump($row);
        // echo $row['c_sex'];
                }

    //if ($_GET['value']=$_GET['c_sex']) {
    //      echo $_GET['c_sex'];
    //       }

    // var_dump($sql);
    // exit;
    // $sql= $pdo->exec("SELECT * FROM client WHERE  VALUES (null,'$_POST[c_name]','$c_state_id','$c_source_id','$_POST[inlineRadioOptions]','$c_type_id',null,'$_POST[c_phone]','$_POST[c_qq]','$_POST[c_email]','$_POST[c_post]','$_POST[c_company]','$_POST[c_other]','$_POST[c_birthday]','$_POST[c_adress]','$_POST[c_modife]','$_POST[c_create]','$_POST[c_blog]','$_POST[c_tel]','$_POST[c_msn]',)");

    ?>

        <!-- 内容 -->
<div class="container col-md-10">
  <h3>添加客户</h3><hr />
  <div class="col-md-9">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4>添加客户信息</h4>
      </div>

      <div class="panel-body">
        <form class="form-horizontal" method="post" action="addclientadmin.php">
          <div class="form-group">

            <label for="inputEmail3" class="col-sm-2 control-label">客户姓名</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="inputEmail3" name="c_name" value="<?php echo $row['c_name']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 control-label ">客户来源</label>
            <div class="col-sm-3">
            <?php
              $host='localhost';
              $user='root';
              $pwd='123456';
              $db='crm';
              $pdo= new PDO("mysql:host=$host;dbname=$db",$user,$pwd);
              $arr = array();
              $sql="SELECT c_source FROM source";
                foreach ($pdo -> query($sql) as $value) {
                  $name = $value['c_source'];
                  $arr[] = $name;
                 }
              echo "<select class='form-control' name='source'>";
                foreach ($arr as $val) {
                  echo "<option value='$val'>".$val."</option>";

                  }
              echo "</select>";
            ?>
            </div>
          </div>

          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">客户职位</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="inputEmail3" name="c_post" value="<?php echo $row['c_post']; ?>">
            </div>
            <label for="inputEmail3" class="col-sm-2 control-label">客户类别</label>
            <div class="col-sm-3">
            <?php
              $host='localhost';
              $user='root';
              $pwd='123456';
              $db='crm';
              $pdo= new PDO("mysql:host=$host;dbname=$db",$user,$pwd);
              $arr = array();
              $sql="SELECT type FROM type";
                foreach ($pdo -> query($sql) as $value) {
                  $name = $value['type'];
                  $arr[] = $name;
                 }
                  echo "<select class='form-control' name='type'>";
                  foreach ($arr as $val) {
                    echo "<option value='$val'>".$val."</option>";
                    }
                  echo "</select>";
            ?>
            </div>
          </div>

          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">客户性别</label>
            <div class="col-sm-3">
              &nbsp;&nbsp;&nbsp;

              <label class="radio-inline">
                <input type="radio" name="inlineRadioOptions" id="inlineRadio1" value="男">男
              </label>
              &nbsp;&nbsp;&nbsp;
              <label class="radio-inline">
                <input type="radio" name="inlineRadioOptions" id="inlineRadio1" value="女">女
              </label>

            </div>

            <label for="inputEmail3" class="col-sm-2 control-label">E-Mail</label>
            <div class="col-sm-3">
              <input type="email" class="form-control" id="inputEmail3" name="c_email">
            </div>
          </div>

          <div class="form-group">

            <label for="inputEmail3" class="col-sm-2 control-label">出生日期</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="inputEmail3" name="c_birthday" value="<?php echo $row['c_birthday']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 control-label">客户状态</label>
            <div class="col-sm-3">
            <?php
              $host='localhost';
              $user='root';
              $pwd='123456';
              $db='crm';
              $pdo= new PDO("mysql:host=$host;dbname=$db",$user,$pwd);
              $arr = array();
              $sql="SELECT c_state FROM state";
                foreach ($pdo -> query($sql) as $value) {
                  $name = $value['c_state'];
                  $arr[] = $name;
                 }
                  echo "<select class='form-control' name='state'>";
                  foreach ($arr as $val) {
                    echo "<option value='$val'>".$val."</option>";
                    }
                  echo "</select>";
            ?>
            </div>
          </div>

          <div class="form-group">

            <label for="inputEmail3" class="col-sm-2 control-label">客户手机</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" id="inputEmail3" name="c_phone" value="<?php echo $row['c_phone']; ?>">
            </div>

            <label for="inputEmail3" class="col-sm-2 control-label">客户QQ</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="inputEmail3" name="c_qq" value="<?php echo $row['c_qq']; ?>">
              </div>
          </div>

          <div class="form-group">

            <label for="inputEmail3" class="col-sm-2 control-label">客户地址</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="inputEmail3" name="c_adress" value="<?php echo $row['c_adress']; ?>">
              </div>

            <label for="inputEmail3" class="col-sm-2 control-label">修改人</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="inputEmail3" name="c_modife" value="<?php echo $row['c_modife']; ?>">
              </div>
          </div>

          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">创建人</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="inputEmail3" name="c_create" value="<?php echo $row['c_create']; ?>">
              </div>

              <label for="inputEmail3" class="col-sm-2 control-label">客户微博</label>
                <div class="col-sm-3">
                  <input type="text" class="form-control" id="inputEmail3" name="c_blog" value="<?php echo $row['c_blog']; ?>">
                </div>
          </div>

          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">客户座机</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="inputEmail3" name="c_tel" value="<?php echo $row['c_tel']; ?>">
              </div>

            <label for="inputEmail3" class="col-sm-2 control-label">客户MSN</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="inputEmail3" name="c_msn" value="<?php echo $row['c_msn']; ?>">
              </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">客户公司</label>
            <div class="col-sm-3">
               <input type="text" class="form-control" id="inputEmail3" name="c_company" value="<?php echo $row['c_company']; ?>">
            </div>
          </div>

          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">备注</label>
            <div class="col-sm-5">
              <textarea cols="45em" rows="3" placeholder="在这里输入备注内容..." name="c_other"> <?php echo $row['c_other']; ?> </textarea>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-primary">提交</button>
              <input type="reset" class="btn btn-info" />
              <button type="submit" class="btn btn-default"><a href="kh_info.php">返回</a></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'common/footer.html' ?>
